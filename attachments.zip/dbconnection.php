<?php 
$con=mysqli_connect('localhost','root','','dbms');
if(mysqli_connect_error())
{
    die("Connection error");
}
?>
